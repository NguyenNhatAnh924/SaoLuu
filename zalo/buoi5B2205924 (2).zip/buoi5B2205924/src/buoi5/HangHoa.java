
package buoi5;

import java.util.InputMismatchException;
import java.util.Scanner;


public class HangHoa {
    private String mso;
    private String ten;


    public HangHoa() {
        this.mso = new String();
        this.ten = new String();
     
    }

    public HangHoa(String mso, String ten, String nsxuat) {
        this.mso = mso;
        this.ten = ten;
  
    }

    public HangHoa(HangHoa h) {
        this.mso = new String(h.mso);
        this.ten = new String(h.ten);

    }

    @Override
    public String toString() {
        return "HangHoa{" + "mso=" + mso + ", ten=" + ten + '}';
    }

    public void nhap(){
        Scanner sc = new Scanner(System.in);
        do {            
            try {
                System.out.println("Nhap ma so hang hoa:");
                this.mso = sc.nextLine();
                System.out.println("Nhap Ten Hang hoa: ");
                this.ten = sc.nextLine();
                break;
            } catch (Exception inputException) {
                System.out.println("Loi dinh dang, Nhap Lại!");
                sc= new Scanner(System.in);
            }
        } while (true);
    }
    
    public void in(){
        System.out.println("Ma so: "+ this.mso+ ", Ten: "+this.ten+", Ngay San Xuat: ");
    }
    
    
    
    
}
