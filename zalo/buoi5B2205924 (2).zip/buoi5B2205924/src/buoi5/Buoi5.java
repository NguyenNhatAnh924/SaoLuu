
package buoi5;

import java.util.Scanner;


public class Buoi5 {

    public static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        HoaDon hd = new HoaDon();
        hd.nhap();
        hd.in();
//        System.out.print("\nNhap so luong hoa don: ");
//	int n = sc.nextInt();
//	HoaDon ds[] = new HoaDon[n];
//	for(int i = 0; i < n; i++){
//            System.out.println("Nhap hoa don thu " + (i+1) + ":");
//            ds[i] = new HoaDon();
//            ds[i].nhap();			
//	}
//	for(int i = 0; i < n; i++){
//            System.out.println("\nHoa don thu " + (i+1) + ":");
//            ds[i].in();
//	}
    }
    
}
