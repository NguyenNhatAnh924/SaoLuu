
package buoi5;

import java.util.ArrayList;

public class DSHoaDon {
    private ArrayList<HoaDon> hd;
    
    public DSHoaDon(){
       this.hd= new ArrayList<HoaDon>();
    }
    
    public DSHoaDon(ArrayList<HoaDon> HD){
        this.hd= new ArrayList<HoaDon>(HD);
    }
    
    public void themHoaDon(HoaDon h){
        this.hd.add(h);
    }
    
    public void inHoaDon(){
        for(int i=0; i<= this.hd.size();i++){
            System.out.println("Hoa Don thu "+i+":");
            this.hd.get(i).in();
        }
    }
}
