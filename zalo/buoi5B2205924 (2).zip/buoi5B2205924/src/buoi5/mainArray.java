
package buoi5;

import java.util.Scanner;


public class mainArray {
    public static void main(String[] args) {
        DSHoaDon ds= new DSHoaDon();
        int n=0;
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhap so luong DS");
        n= sc.nextInt();
        for(int i=0;i<n; i++){
            HoaDon hd = new HoaDon();
            System.out.println("Nhap Hoa Don thu "+(i+1)+":");
            hd.nhap();
            ds.themHoaDon(hd);
        }
        
       for(int i=0;i<n;i++){
           ds.inHoaDon();
       }
    }
}
