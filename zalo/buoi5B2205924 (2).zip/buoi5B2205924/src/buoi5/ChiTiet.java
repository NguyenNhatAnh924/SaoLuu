
package buoi5;

import java.util.Scanner;

public class ChiTiet {
    private HangHoa hh;
    private int sl;
    private float dgia;

    public ChiTiet() {
        this.hh = new HangHoa();
        this.dgia= 0;
        this.sl=0;   
    }

    public ChiTiet(HangHoa hh, int sl, float dgia) {
        this.hh = new HangHoa(hh);
        this.sl = sl;
        this.dgia = dgia;
    }

    public ChiTiet(ChiTiet c) {
        this.hh = new HangHoa(c.hh);
        this.sl = c.sl;
        this.dgia= c.dgia;
    }

    @Override
    public String toString() {
        return "ChiTiet{" + "hh=" + hh + ", sl=" + sl + ", dgia=" + dgia + '}';
    }
    
    
    public void nhap(){
        Scanner sc = new Scanner(System.in);
        do {            
        try {
         System.out.println("Nhap Hang Hoa: ");
        this.hh.nhap();
         System.out.println("Nhap so luong: ");
        this.sl= sc.nextInt();
         System.out.println("Nhap don gia: ");
        this.dgia = sc.nextFloat();    
         break;
        } catch (Exception inputException) {
            System.out.println("Loi dinh dang, Nhap lai! ");
            sc = new Scanner(System.in);
        }
        } while (true);
       
 
    }
    
    public void in(){
        this.hh.in();
        System.out.println("So luong: "+this.sl+", Don Gia: "+this.dgia);
    }
    
    public float giaTien(){
        return (float)(this.sl*this.dgia);
    }
    
}
