
package buoi5;

import java.util.Scanner;


public class Date {
   private int ngay,thang,nam;

    public Date(int ngay, int thang, int nam) {
        this.ngay = ngay;
        this.thang = thang;
        this.nam = nam;
    }
    
    public Date(Date a) {
        this.ngay = a.ngay;
        this.thang = a.thang;
        this.nam = a.nam;
    }

    public Date() {
           this.ngay = 1;
        this.thang = 1;
        this.nam = 1900;
    }
    
    

    public int getNgay() {
        return ngay;
    }

    public int getThang() {
        return thang;
    }

    public int getNam() {
        return nam;
    }

    public void setNgay(int ngay) {
        this.ngay = ngay;
    }

    public void setThang(int thang) {
        this.thang = thang;
    }

    public void setNam(int nam) {
        this.nam = nam;
    }
    public boolean nhuan(int year){
        return (year % 4 == 0) && (year % 100!= 0) || (year%400 == 0);
    }
    
    public boolean kiemTra(int x, int y, int z){
      if(z==0){
          return false;
      }
      if(y==0|| y>12){
          return false;
      }
      if(y==0|| x>31){
          return false;
      }
      if(y==2){
          if(nhuan(z)==true){
              return (x>0&& x<=29);
          }
          else{
              return (x>0&& x<=28);
          }
      }
      if(y==1|| y==3|| y==5|| y==7|| y==8|| y==10|| y==12){
            return (x>0&& x<=31);
      }
      else{
            return (x>0&& x<=30);
      }
    
    }
    
      public  void nhapDate(){
            Scanner sc = new Scanner(System.in);
             int a = 0, b=0, c=0;
            do {             
            System.out.println("Nhap ngay");    a =sc.nextInt();
            System.out.println("Nhap Thang");   b=sc.nextInt();
            System.out.println("Nhap nam");     c=sc.nextInt();
            if(kiemTra(a, b, c)==true){
                this.nam=c;
                this.ngay=a;
                this.thang=b;
            }
            else{
                System.out.println("Khong hop le!");
            }
       
          } while (!kiemTra(a, b, c));
           
           
            
  }
   
    public void printDate(){
        System.err.println(this.ngay+"/ "+this.thang+"/ "+this.nam);
    }

    @Override
    public String toString() {
        return "{" + ngay + "/" + thang + "/" + nam + '}';
    }
   
    
    
  public Date ngayHomSau(){
      Date a =new Date(this.ngay,this.thang,this.nam);
      if(a.thang==2){
          if(nhuan(a.nam)==true){
              if(a.ngay==29){
                  a.ngay=1;
                  a.thang++;
                  return a;
              }
          }
          else{
              if(a.ngay==28){
                  a.ngay=1;
                  a.thang++;
                  return a;
              }
          }
      }
      if(a.thang==12 && a.ngay==31){
          a.ngay=1;
          a.thang=1;
          a.nam++;
          return a;
      }
      if(a.thang==1|| a.thang==3|| a.thang==5|| a.thang==7|| a.thang==8|| a.thang==10){
          if(a.ngay==31){
                  a.ngay=1;
                  a.thang++;
                  return a;
              }
      }
      else{
           if(a.ngay==30){
                  a.ngay=1;
                  a.thang++;
                  return a;
              }
      }
      a.ngay++;
        return a;
  }
  
  public Date congNgay(int n){
       Date a =new Date(this.ngay,this.thang,this.nam);
       int i;
       for(i=0;i<=n-1;i++){
           a=new Date(a.ngayHomSau());
       }
      return a;
  }
}
