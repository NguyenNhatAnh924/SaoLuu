
package buoi5;

import java.util.Scanner;

public class KhachHang {
    private String cccd;
    private String hten;
    private String dchi;

    public KhachHang(String cccd, String hten, String dchi) {
        this.cccd = cccd;
        this.hten = hten;
        this.dchi = dchi;
    }

    public KhachHang() {
        this.cccd = new String();
        this.dchi=  new String();
        this.hten =  new String();
    }

    public KhachHang(KhachHang a) {
        this.cccd = new String(a.cccd);
        this.dchi = new String(a.dchi);
        this.hten = new String(a.hten);
    }

    @Override
    public String toString() {
        return "KhachHang{" + "cccd=" + cccd + ", hten=" + hten + ", dchi=" + dchi + '}';
    }
    
    public void nhap(){
        Scanner sc= new Scanner(System.in);
        do {            
            try {
                System.out.println("Nhap CCCD"); this.cccd= sc.nextLine();
                System.out.println("Nhap dia chi: "); this.dchi= sc.nextLine();
                System.out.println("Nhap ho va ten: "); this.hten = sc. nextLine();
                break;
            } catch (Exception inputException) {
                System.out.println("Loi dinh dang, Nhap laij!");
                sc = new Scanner(System.in);
            }
        } while (true);
    }
    
    public void in(){
        System.out.println("CCCD: "+this.cccd+" , Dia Chi: "+this.dchi+" , Ho va ten: "+this.hten);
    }
    
}
