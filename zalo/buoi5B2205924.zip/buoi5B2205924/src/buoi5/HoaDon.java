
package buoi5;

import java.util.Scanner;

public class HoaDon {
    private String mso;
    private String tde;
    private String nvien;
    private KhachHang khang;
    private ChiTiet ctiet[];
    private Date ngay;
    private int sl;

    public HoaDon() {
        this.mso= new String();
        this.nvien= new String();
        this.tde = new String();
        this.khang = new KhachHang();
        this.ctiet = new ChiTiet[10];
        this.ngay = new Date();
        this.sl=0;
    }
    
    public HoaDon(HoaDon b){
        this.mso= new String(b.mso);
        this.nvien = new String(b.nvien);
        this.tde= new String(b.tde);
        this.khang = new KhachHang(b.khang);
        this.ctiet = new ChiTiet[b.ctiet.length];
        for(int i=0 ; i<= b.ctiet.length;i++){
            this.ctiet[i] = new ChiTiet();
            this.ctiet[i]= new ChiTiet(b.ctiet[i]);
        }
        this.ngay = new Date(b.ngay);
        this.sl=b.sl;
    }

    @Override
    public String toString() {
        return "HoaDon{" + "mso=" + mso + ", tde=" + tde + ", nvien=" + nvien + '}';
    }
    
    public void nhap(){
        do {            
            try {
                Scanner sc = new Scanner(System.in);
                int n;
                System.out.println("Nhap mso hoa don: "); this.mso = sc.nextLine();
                System.out.println("Nhap nvien hoa don: "); this.nvien = sc.nextLine();
                System.out.println("Nhap tde hoa don: "); this.tde = sc.nextLine();
                sc = new Scanner(System.in);
                System.out.println("Nhap 1 neu la khach hang VIP"
                        + ", Nhap 0 neu la khach hang.");
                n= sc.nextInt();
                if(n==1){
                    this.khang= new KhachHangVIP();
                }else{
                    this.khang = new KhachHang();
                }
                this.khang.nhap();
                sc = new Scanner(System.in);
                System.out.println("Nhap so luong san pham: ");
                this.sl = sc.nextInt();
                for(int i=0 ; i<this.sl;i++){
                    System.out.println("Nhap san pham thu "+(i+1));
                    this.ctiet[i]= new ChiTiet();
                    this.ctiet[i].nhap();
                }
                System.out.println("Nhap ngay cua Hoa Don: ");
                this.ngay.nhapDate();
                break;
            } catch (Exception inException) {
                System.out.println("Loi dinh dang, Nhap lai!");
            }
        } while (true);
    }
    
     public float tong(){
        float kq=0;
            for(int i=0; i< this.sl;i++){
                kq+= this.ctiet[i].giaTien();
            }
        return kq;
    }
    
    public void in(){
        System.out.println("Thong tin Hoa Don:");
        System.out.println("mso hoa don: "+ this.mso+", tde hoa don: "+this.tde+", nvien: "+this.nvien);
        System.out.println("Thoong tin khach hang:");
        this.khang.in();
        System.out.println("Ngay mua hang");
        this.ngay.printDate();
        for(int i = 0; i< this.sl;i++){
            this.ctiet[i].in();
        }
        System.out.println("Tong tien: "+tong());
    }
    
   
}
