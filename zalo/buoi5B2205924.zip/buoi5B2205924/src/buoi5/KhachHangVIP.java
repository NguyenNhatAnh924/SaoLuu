
package buoi5;

import java.util.Scanner;

public class KhachHangVIP extends KhachHang{
    private  float tlegiam;
    private Date time;

    public KhachHangVIP() {
        super();
        this.time= new Date();
        this.tlegiam = 0;
    }

    public KhachHangVIP(KhachHangVIP k) {
        super(k);
        this.tlegiam = k.tlegiam;
        this.time= new Date(k.time);
    }

    @Override
    public String toString() {
        return "KhachHangVIP{" + "tlegiam=" + tlegiam + ", time=" + time.toString() + '}';
    }
    
    @Override
    public void nhap(){
        Scanner sc = new Scanner(System.in);
        do {            
            try {
                super.nhap();
                System.out.println("Nhap te le giam: "); this.tlegiam = sc.nextFloat();
                this.time.nhapDate();
                break;
            } catch (Exception inputException) {
                System.out.println("Loi Dinh dang, Nhap lai!");
                sc= new Scanner(System.in);
            }
        } while (true);

    }
    
    @Override
    public void in(){
        super.in();
        System.out.println("Ti le giam: "+(this.tlegiam*100)+", Thoi gian: "+ this.time.toString());
    }
    
}
