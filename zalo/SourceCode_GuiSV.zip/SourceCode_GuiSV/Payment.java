//Dont modify this file

interface Payment {
    public boolean pay(double amount);
    public double checkBalance();
}