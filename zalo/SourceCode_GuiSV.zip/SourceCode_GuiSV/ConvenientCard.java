// public class ConvenientCard {
	public class ConvenientCard implements Payment{
		// code here
	}
	