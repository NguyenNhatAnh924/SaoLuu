
package buoi5;

import java.util.Scanner;

public class ChiTiet {
    private String mso;
    private String ten;
    private int sl;
    private float dgia;

    public ChiTiet() {
        this.mso = new String();
        this.ten = new String();
        this.sl=0;
        this.dgia=0;
    }

    public ChiTiet(String mso, String ten, int sl, float dgia) {
        this.mso = new String(mso);
        this.ten = new String(ten);
        this.sl = sl;
        this.dgia = dgia;
    }

    public String getMso() {
        return mso;
    }

    public String getTen() {
        return ten;
    }

    public int getSl() {
        return sl;
    }

    public float getDgia() {
        return dgia;
    }

    public void setMso(String mso) {
        this.mso = mso;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public void setSl(int sl) {
        this.sl = sl;
    }

    public void setDgia(float dgia) {
        this.dgia = dgia;
    }

    @Override
    public String toString() {
        return "ChiTiet{" + "mso=" + mso + ", ten=" + ten + ", sl=" + sl + ", dgia=" + dgia + '}';
    }
    
    public float TongTien(){
        float kq=0;
        kq= this.sl* this.dgia;
        return kq;
    }
}
