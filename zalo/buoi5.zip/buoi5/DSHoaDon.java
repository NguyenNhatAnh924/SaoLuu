
package buoi5;

import java.util.ArrayList;

public class DSHoaDon {
    private ArrayList<HoaDon> hd;
    
    
    public DSHoaDon(){
       this.hd= new ArrayList<HoaDon>();
    }
    
    public DSHoaDon(ArrayList<HoaDon> HD){
        this.hd= new ArrayList<HoaDon>(HD);
    }
    
    public void themHoaDon(HoaDon h){
        this.hd.add(h);
    }

    public ArrayList<HoaDon> getHd() {
        return hd;
    }

    public void setHd(ArrayList<HoaDon> hd) {
        this.hd = hd;
    }
    
   
}
