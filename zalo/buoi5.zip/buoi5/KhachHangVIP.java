
package buoi5;

public class KhachHangVIP {
    private String cccd;
    private String hten;
    private String dchi;
    private  float tlegiam;
    private Date time;

    public KhachHangVIP() {
        this.cccd = new String();
        this.dchi=  new String();
        this.hten =  new String();
        this.time= new Date();
        this.tlegiam = 0;
    }

    public KhachHangVIP(String cccd, String hten, String dchi, float tlegiam, Date time) {
        this.cccd = cccd;
        this.hten = hten;
        this.dchi = dchi;
        this.tlegiam = tlegiam;
        this.time = time;
    }
    
    public String getCccd() {
        return cccd;
    }

    public String getHten() {
        return hten;
    }

    public String getDchi() {
        return dchi;
    }

    public float getTlegiam() {
        return tlegiam;
    }


    public void setCccd(String cccd) {
        this.cccd = new String(cccd);
    }

    public void setHten(String hten) {
        this.hten = new String(hten);
    }

    public void setDchi(String dchi) {
        this.dchi = new String(dchi);
    }

    public void setTlegiam(float tlegiam) {
        this.tlegiam = tlegiam;
    }

   

    public void setTime(int ngay, int thang, int nam) {
        this.time.setNgay(ngay);
        this.time.setNam(nam);
        this.time.setThang(thang);
    }

   
   
    

    public float giamGia(){
        return (float)(this.tlegiam/100);
    }
}
