
package buoi5;

import java.util.Scanner;

public class KhachHang {
    private String cccd;
    private String hten;
    private String dchi;

    public KhachHang(String cccd, String hten, String dchi) {
        this.cccd = cccd;
        this.hten = hten;
        this.dchi = dchi;
    }

    public KhachHang() {
        this.cccd = new String();
        this.dchi=  new String();
        this.hten =  new String();
    }


    @Override
    public String toString() {
        return "KhachHang{" + "cccd=" + cccd + ", hten=" + hten + ", dchi=" + dchi + '}';
    }

    public String getCccd() {
        return cccd;
    }

    public String getHten() {
        return hten;
    }

    public String getDchi() {
        return dchi;
    }

    public void setCccd(String cccd) {
        this.cccd = cccd;
    }

    public void setHten(String hten) {
        this.hten = hten;
    }

    public void setDchi(String dchi) {
        this.dchi = dchi;
    }
    
    public boolean isVip(){
        return false;
    }
    
    public float giamGia(){
        return 0;
    }
}
