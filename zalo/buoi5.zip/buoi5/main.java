
package buoi5;


public class main {
    public static void main(String[] args) {
     HoaDon a= new HoaDon("01", "01", "01", "0123456789", "Nguyen Van A", "Tra Vinh",10, 10, 1, 2023, "012", "But", 10, 1000, 1, 1, 2023);
    }
}
