
package buoi5;

import java.util.InputMismatchException;
import java.util.Scanner;


public class HangHoa {
    private String mso;
    private String ten;


    public HangHoa() {
        this.mso = new String();
        this.ten = new String();
     
    }

    public HangHoa(String mso, String ten, String nsxuat) {
        this.mso = mso;
        this.ten = ten;
  
    }

    public HangHoa(HangHoa h) {
        this.mso = new String(h.mso);
        this.ten = new String(h.ten);

    }

    @Override
    public String toString() {
        return "HangHoa{" + "mso=" + mso + ", ten=" + ten + '}';
    }

    public String getMso() {
        return mso;
    }

    public String getTen() {
        return ten;
    }

    public void setMso(String mso) {
        this.mso = mso;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }


    
    
    
}
