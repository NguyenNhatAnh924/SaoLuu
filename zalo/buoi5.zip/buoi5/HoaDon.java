
package buoi5;

import java.util.Scanner;

public class HoaDon {
    private String mso;
    private String tde;
    private String nvien;
    private KhachHangVIP khang;
    private ChiTiet ctiet;
    private Date ngay;
 

    public HoaDon() {
        this.mso= new String();
        this.nvien= new String();
        this.tde = new String();
        this.khang = new KhachHangVIP();
        this.ctiet = new ChiTiet();
        this.ngay = new Date();
      
    }

    public HoaDon(String mso, String tde, String nvien, String cccd,String hten,String dchi,float tlegiam,int ngayk,int thangk,int namk, String mshh, String tenhh,int sl,float dgia , int ngay,int thang, int nam) {
        this.mso = mso;
        this.tde = tde;
        this.nvien = nvien;
        this.khang = new KhachHangVIP();
        this.khang.setCccd(cccd);
        this.khang.setDchi(dchi);
        this.khang.setHten(hten);
        this.khang.setTlegiam(tlegiam);
        this.khang.setTime(ngayk, thangk, namk);
        this.ctiet = new ChiTiet();
        this.ctiet.setMso(mso);
        this.ctiet.setTen(tenhh);
        this.ctiet.setSl(sl);
        this.ctiet.setDgia(dgia);
        this.ngay= new Date();
        this.ngay.setNam(nam);
        this.ngay.setNgay(ngay);
        this.ngay.setThang(thang);
       
    }

    public String getMso() {
        return mso;
    }

    public String getTde() {
        return tde;
    }

    public String getNvien() {
        return nvien;
    }

    public String gettenKhang() {
        return khang.getHten();
    }
    
    public String gettenCtiet() {
        return this.ctiet.getTen();
    }
    
    public int getslChitiet() {
        return this.ctiet.getSl();
    }
    
    public float getDonGiaCtiet() {
        return this.ctiet.getDgia();
    }
   public float getTeLeGiamKhang() {
        return khang.getTlegiam();
    }
    public ChiTiet getCtiet() {
        return ctiet;
    }

    public Date getNgay() {
        return ngay;
    }
  
    
    
     public float tong(){
        float kq=this.ctiet.TongTien();    
         return (kq-(kq* this.khang.giamGia()));        
     } 
}
