/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package b4;

import java.util.Scanner;

/**
 *
 * @author duc
 */
public class B4 {

    /**
     * Viết chương trình nhập vào 2 số nguyên a và b. Tính tổng và hiển thị ra
     * màn hình. Nếu số nhập vào không đúng định dạng thì hiển thị thông báo
     * lỗi, yêu cầu nhập lại.
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        while (true) {
            try {
                System.out.println("Nhap 2 so nguyen a va b: ");
                int a = input.nextInt();
                int b = input.nextInt();
                System.out.println("tong cua 2 so nguyen a va b la: " + (a + b));
                break;
            } catch (Exception InputMismatchEception) {
                System.out.println("Sai dinh dang, nhap lai: ");
                input.nextLine();
            }
        }

    }

}
