/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package b6;

/**
 *
 * @author student
 */
import java.util.Scanner;

public class B6 {

    /**
     * Viết chương trình nhập vào 1 số nguyên. Kiểm tra xem số đó có phải là số
     * nguyên tố không? Hiển thị số nguyên đó ra màn hình dưới dạng số nhị phân
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner ipt = new Scanner(System.in);
        int n, uoc = 0;
        String decimal = "";
         System.out.println("Nhap vao so nguyen: ");
        n = ipt.nextInt();
        for (int i = 1; i < Math.sqrt(n); i++) {
            if (n % 2 == 0) {
                uoc += 1;
            }
        }
        if (uoc <= 2) {
            System.out.println(n + " la so nguyen to");
            int temp = n;
            while (n > 0) {
                decimal += n % 2;
                n /= 2;
            }
            StringBuffer sbr;
            sbr = new StringBuffer(decimal);
             System.out.println("So nguyen " + temp + " duoi dang nhi phan la: ");
            System.out.println(sbr.reverse());
        } else {
            System.out.println(n + " khong la so nguyen to");
        }

    }
}
