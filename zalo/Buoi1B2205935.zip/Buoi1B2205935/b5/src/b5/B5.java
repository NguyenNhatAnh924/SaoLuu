/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package b5;

/**
 *
 * @author student
 */
import java.util.Scanner;

public class B5 {

    /**
     * Viết chương trình giải phương trình bậc 2 trong đó gồm 2 hàm static giải
     * phương trình bậc 1 (2 tham số) và giải phương trình bậc 2 (3 tham số).
     *
     */
    public static void main(String[] args) {
        
        e1(3, 3);
        e2(2, 15, 8);
    }

    public static void e1(float a, float b) {
        //pt co dang ax + b =0
        float x;
        if (a == 0) {
            if (b == 0) {
                System.out.println("Phuong trinh co vo so nghiem!");
            } else {
                System.out.println("Phuong trinh vo nghiem!");
            }
        } else {
            x = -b / a;
            System.out.println(x);
        }
    }

    public static void e2(float a, float b, float c) {
        float x1, x2;
        if (a == 0) {
            e1(a, b);
        } else {
            float delta = (float) (Math.pow(b, 2) - 4 * a * c);
            if (delta < 0) {
                System.out.println("Phuong trinh vo nghiem!");
            } else if (delta == 0) {
                x1 = -b / (2 * a);
                System.out.println("Phuong trinh co nghiem kep: " + x1);
            } else {
                x1 = (float) ((-b + Math.sqrt(delta)) / (2 * a));
                x2 = (float) ((-b - Math.sqrt(delta)) / (2 * a));
                System.out.println("Phuong trinh co 2 nghiem phan biet: " + x1 + "   " + x2);
            }
        }
    }

}
