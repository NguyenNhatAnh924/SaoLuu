/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package b7;

import java.util.Scanner;

/**
 *
 * @author duc
 */
public class B7 {

    /**
     * Viết chương trình nhập vào 1 chuỗi họ tên. Hiển thị ra tên của họ tên đó.
     * Nên thiết kế chương trình gồm 1 hàm dùng để tách tên và hàm main.
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner ipt = new Scanner(System.in);
        String hoTen;
        System.out.println("Nhap vao ho va ten ");
        hoTen = ipt.nextLine();
        String ten = tachTen(hoTen);
        System.out.println(ten);

    }

    public static String tachTen(String name) {
        String[] n = name.split(" ");
        return n[n.length - 1];
    }

}
