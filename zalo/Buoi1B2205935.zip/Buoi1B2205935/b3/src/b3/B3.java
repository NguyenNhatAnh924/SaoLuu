/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package b3;

/**
 *
 * @author student
 */
import java.util.Scanner;

public class B3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int n = 0;
        float[] arr;

        Scanner input = new Scanner(System.in);

        do {
            try {
                System.out.println("So luong phan tu cua danh sach so thuc: ");
                n = input.nextInt();
                arr = new float[n];
                for (int i = 0; i < n; i++) {
                    arr[i] = input.nextFloat();
                }
                break;
            } catch (Exception InputMismatchException) {
                System.out.println("Loi dinh dang, nhap lai: ");
                input.nextLine();
            }
        } while (true);
        float max = 0, sum = 0;
        for(float pt: arr){
            if (max < pt) max = pt;
            sum += pt;
        }
        System.out.println("Phan tu lon nhat trong mang la: " + max);
        System.out.println("Tong cac phan tu cua mang la: " + sum);
    }

}
