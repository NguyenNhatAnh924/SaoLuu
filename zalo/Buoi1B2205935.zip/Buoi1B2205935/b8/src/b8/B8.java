/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package b8;

/**
 *
 * @author duc
 */
import java.util.Arrays;
import java.util.Scanner;

public class B8 {

    /**
     * Viết chương trình thực hiện các công việc sau: Nhập vào 1 danh sách các
     * số nguyên. Nhập vào 1 số nguyên x bất kỳ. Đếm xem trong danh sách có bao
     * nhiêu số x. Sắp xếp danh sách theo thứ tự tăng dần. Hiển thị danh sách ra
     * màn hình.
     */
    public static void main(String[] args) {
        Scanner ipt = new Scanner(System.in);
        System.out.println("Nhap vao so luong phan tu cua mang: ");
        int n = ipt.nextInt();
        int sl = 0;
        int[] arr = new int[n];
        System.out.println("Nhap vao phan tu cua mang: ");
        for (int i = 0; i < n; i++) {
            arr[i] = ipt.nextInt();
        }
        System.out.println("Nhap vao phan tu can tim: ");
        int x = ipt.nextInt();
        for (int pt : arr) {

            if (pt == x) {
                sl += 1;
            }

        }
        System.out.println(sl);
        for (int i = 0; i < n; i++) {

            for (int j = i + 1; j < n; j++) {

                if (arr[j] < arr[i]) {
                    int temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;

                }
            }
        }
        System.out.println("Mang sau khi da sap xep: ");
        System.out.println(Arrays.toString(arr));
    }

}
