//add su kien
const headerSearch = document.querySelector(".search-input");
const buttonSearch = document.querySelector(".icon1");
const handleSearch = (e) => {
  if (!headerSearch.value) {
    e.preventDefault();
  }
};
//shop
buttonSearch.addEventListener("click", handleSearch);
headerSearch.addEventListener("keypress", (e) => {
  if (e.keyCode == 13) {
    handleSearch(e);
  }
});
const listInput = document.querySelectorAll('input[type="number"]');
const listBtn = document.querySelectorAll('input[type="number"] + button');

function opencard() {
  location.href = "./donhang.html";
}
const itemList = {
  sp001: {
    name: "Giầy thể thao",
    price: 299000,
    photo: "../img/giay.jpg",
  },
  sp002: {
    name: "Áo khoác",
    price: 99000,
    photo: "../img/ao.jpg",
  },
  sp003: {
    name: "Sổ tay",
    price: 39000,
    photo: "../img/sotay.jpg",
  },
  sp004: {
    name: "Quà lưu niệm",
    price: 249000,
    photo: "../img/qua_luu_niem.jpg",
  },
  sp005: {
    name: "Chó bông",
    price: 749000,
    photo: "../img/cho_bong.jpg",
  },
  sp006: {
    name: "Đèn lưu niệm",
    price: 149000,
    photo: "../img/den_luu_niem.jpg",
  },
  sp007: {
    name: "Heo bông",
    price: 349000,
    photo: "../img/heo_bong.jpg",
  },
  sp008: {
    name: "Móc khóa",
    price: 99000,
    photo: "../img/moc_khoa.jpg",
  },
  sp009: {
    name: "Móc khóa đồng hồ",
    price: 99000,
    photo: "../img/moc_khoa_dong_ho.jpg",
  },
  sp010: {
    name: "Bút máy",
    price: 599000,
    photo: "../img/but_may.jpg",
  },
  sp011: {
    name: "Hoa sáp",
    price: 99000,
    photo: "../img/hoa_sap.JPG",
  },
  sp012: {
    name: "Quả cầu pha lê",
    price: 250000,
    photo: "../img/qua_cau_pha_le.JPG",
  },
};

//lay tat ca cac key tu cua obj luu vao mang
const listKey = Object.keys(itemList);

const setItemLocal = (i, total) => {
  if (total > 100) {
    alert("so luong dat qua 100 san pham");
    window.localStorage.setItem(listKey[i], 100);
  } else {
    alert("Đặt hàng thành công");
    window.localStorage.setItem(listKey[i], total);
  }
};

const handleClick = (i) => {
  if (+listInput[i].value) {
    if (typeof window.localStorage[listKey[i]] === "undefined") {
      setItemLocal(i, +listInput[i].value);
      listInput[i].value = "0";
    } else {
      const number = +listInput[i].value;
      const current = +window.localStorage.getItem(listKey[i]);
      const total = number + current;
      listInput[i].value = "0";
      setItemLocal(i, total);
    }
  } else {
    alert("Vui lòng thêm số lượng sản phẩm");
  }
};

[...listBtn].forEach((btn, i) => {
  btn.addEventListener("click", () => handleClick(i));
});
