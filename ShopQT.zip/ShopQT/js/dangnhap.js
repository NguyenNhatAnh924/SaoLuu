
    var account = '{"taikhoan":[{"username":"shopfivepandas","password":"12345678"}]}';
    var obj = JSON.parse(account);
    function frmValidate(){
        var frm = document.forms['login'];
        var user = frm.user;
        var pw = frm.pw;
        if((user.value== obj.taikhoan[0].username)&&(pw.value== obj.taikhoan[0].password)){
        alert('Đăng nhập thành công');
        location.href = "../project/index.html";
    }
        else
        alert('Bạn đã nhập sai tài khoản hoặc mật khẩu !');
    }