var frm = document.querySelector("#frm");

    function registeruser(frm) {
      frm.addEventListener("click", function (e) {
        e.preventDefault;
      });
      var passwordreg = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})");
      emailreg = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if (frm.hoten.value.length <= 0) {
            alert("Vui lòng nhập tên của bạn !");
            frm.hoten.focus();
            return false;
        }
        
        var currentYear = new Date().getFullYear();
        var userYear = new Date(frm.ns.value).getFullYear();
        var ageuser = currentYear - userYear;
        if(ageuser < 18 || isNaN(ageuser)){
            alert("Bạn chưa đủ tuổi !");
            frm.ns.focus();
            return false;
        }
        if (frm.address.value.length <=0){
                alert("Địa chỉ không hợp lệ vui lòng nhập lại !");
                frm.address.focus();
                return false;
        }
        if (frm.phone.value.length !=10){
                alert("Số điện thoại không hợp lệ vui lòng nhập lại");
                frm.phone.focus();
                return false;
        }
        if (emailreg.test(frm.email.value)==false){
            alert("Email không hợp lệ vui lòng nhập lại");
            frm.email.focus();
            return false;
        }
        if (passwordreg.test(frm.password.value)==false){
                alert("Mật khẩu gồm chữ hoa, chữ thường và kí tự đặc biệt");
                frm.password.focus();
                return false;
            }
            
        if(frm.password.value != frm.repeatpassword.value){
                alert("Mật khẩu không khớp");
                frm.repeatpassword.focus();
                return false;
        }
      alert("Đăng ký thành công !");
      location.reload();
      return true;
    }